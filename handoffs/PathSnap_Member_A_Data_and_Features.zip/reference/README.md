# PathSnap — Distributed Map-Matching & Route Reconstruction

[![Python 3.11](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/release/python-3110/)
[![FastAPI](https://img.shields.io/badge/FastAPI-1.0.0-009688.svg)](https://fastapi.tiangolo.com)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.67.0-FF4B4B.svg)](https://streamlit.io)
[![Tests Passing](https://img.shields.io/badge/tests-26%20passed-brightgreen.svg)]()

**PathSnap** is a distributed machine learning and sequential map-matching system developed for **UE24CS352A (Machine Learning)** at the Department of Computer Science & Engineering, PES University. 

It reconstructs realistic vehicle trajectories by matching noisy, sparse GPS observations onto complex road networks using an ensemble candidate scoring model combined with an **HMM and Viterbi dynamic programming decoder**.

---

## 🏛️ System Architecture

```mermaid
flowchart TD
    subgraph Data & Feature Pipeline
        A["Raw GPS (.track) & Road Subgraphs (.nodes, .arcs)"] --> B["Data Loader (Haversine & Azimuth)"]
        B --> C["Spatial Indexing (STRtree Candidate Generation)"]
        C --> D["Feature Engineering (14 Geometric, Kinematic & Rank Features)"]
    end

    subgraph Machine Learning & Optimization
        D --> E["5-Fold Trip-Aware GroupKFold CV"]
        E --> F["5 Model Pipelines (Linear, RF, Boosting, KNN, MLP)"]
        F --> G["Bayesian Optimization (Optuna TPE - 12 Trials)"]
        G --> H["Tuned Model Artifact (tuned_model.joblib)"]
    end

    subgraph Sequential Route Reconstruction
        H --> I["Observation Emission Probabilities"]
        B --> J["Directed Road Graph Shortest-Paths"]
        I & J --> K["Log-Space Viterbi Trellis Dynamic Programming"]
        K --> L["Continuous Reconstructed Route (Arc Sequence)"]
    end

    subgraph Distributed Deployment
        L --> M["FastAPI Inference Server (Laptop 1)"]
        M --> N["Streamlit Interactive Evaluator UI (Laptop 2)"]
    end
```

---

## 📁 Repository Structure

```
PathSnap_Phase1_Team_Scaffold/
├── data/
│   ├── raw/
│   │   └── Student folder/
│   │       ├── train/              # 80 training trips (.track, .nodes, .arcs, .route)
│   │       └── student_test/       # 10 development evaluation trips
│   └── processed/                  # Cached candidate feature datasets
├── docs/                           # Specification documents, guidelines & technical report
│   ├── INTEGRATION_CONTRACT.md     # Module interface definitions & contracts
│   └── FINAL_TECHNICAL_REPORT.md   # Comprehensive hackathon technical report
├── frontend/
│   ├── app.py                      # Interactive Streamlit Evaluator Dashboard
│   └── README.md                   # Frontend execution notes
├── models/                         # Serialized model artifacts & metadata
│   ├── tuned_model.joblib          # Final Bayesian-tuned Random Forest pipeline
│   ├── RandomForest.joblib         # Untuned Random Forest pipeline
│   ├── HistGradientBoosting.joblib # Gradient Boosting pipeline
│   ├── LogisticRegression.joblib   # Linear pipeline
│   ├── KNN.joblib                  # Instance-based pipeline
│   ├── MLP_NeuralNet.joblib        # Neural Network pipeline
│   └── feature_metadata.json       # Feature configuration metadata
├── results/
│   ├── eda/                        # EDA summary tables, distributions & interactive maps
│   ├── model_comparison/           # Multi-model metrics, comparison CSVs & comparison plots
│   ├── optimization/               # Bayesian optimization trial history & trajectory plots
│   └── maps/                       # Folium interactive maps & reconstruction plots
├── src/
│   ├── data/
│   │   ├── loader.py               # Raw file loader, geodesic distance & azimuth
│   │   └── exploration.py          # EDA analysis, NetworkX graph stats & Folium plots
│   ├── features/
│   │   ├── candidates.py           # STRtree spatial indexing & candidate generation
│   │   ├── engineering.py          # 14 geometric, kinematic & spatial ranking features
│   │   └── dataset.py              # Labeling logic & training dataset builder
│   ├── models/
│   │   └── baselines.py            # 5 ML model pipelines & candidate prediction scorer
│   ├── training/
│   │   ├── train.py                # GroupKFold cross-validation & training runner
│   │   └── optimization.py         # Optuna Bayesian hyperparameter optimization
│   ├── evaluation/
│   │   └── metrics.py              # Macro F1, observation Top-1 accuracy & continuity
│   ├── reconstruction/
│   │   └── viterbi.py              # HMM emission/transition modeling & Viterbi decoder
│   └── api/
│       └── main.py                 # FastAPI backend server
├── tests/                          # 26 unit, integration and API tests
│   ├── test_api/                   # FastAPI endpoint tests
│   ├── test_data/                  # Loader and EDA tests
│   ├── test_features/              # Candidates and feature engineering tests
│   ├── test_models/                # Model, cross-validation and Optuna tests
│   ├── test_reconstruction/        # Graph building and Viterbi decoding tests
│   └── test_integration_pipeline.py# Complete end-to-end integration test
├── requirements.txt                # Python dependencies
└── README.md                       # Master execution documentation
```

---

## ⚡ Quick Setup & Installation

### 1. Environment Setup
```bash
# Clone the repository
git clone https://github.com/your-team/PathSnap.git
cd PathSnap

# Create and activate virtual environment
python -m venv .venv

# Windows PowerShell:
.\.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate

# Install all project dependencies
pip install -r requirements.txt
```

---

## 🚀 Execution Guide

### 1. Run Complete Test Suite (26 Tests)
```bash
python -m pytest tests -v
```

### 2. Run Exploratory Data Analysis (EDA)
Runs structured EDA across all 80 training trips and 10 testing trips, exporting summary statistics and interactive Folium maps to `results/eda/`:
```bash
python -c "from src.data.exploration import run_full_eda; run_full_eda()"
```

### 3. Train & Compare 5 Distinct ML Models
Performs 5-Fold trip-aware `GroupKFold` cross-validation across all 5 models and evaluates on student-testing trips:
```bash
python -c "
import pandas as pd
from src.training.train import train_models
train_df = pd.read_csv('data/processed/train_features_sample.csv.gz')
test_df = pd.read_csv('data/processed/test_features.csv.gz')
train_models(train_df, test_df)
"
```

### 4. Run Bayesian Hyperparameter Optimization
Executes Optuna Bayesian optimization (TPE Sampler) on the ensemble architecture, refits the tuned model, and outputs trial history to `results/optimization/`:
```bash
python -c "
import pandas as pd
from src.training.optimization import optimize_random_forest
train_df = pd.read_csv('data/processed/train_features_sample.csv.gz')
optimize_random_forest(train_df, n_trials=12)
"
```

### 5. Run HMM Route Reconstruction Experiment
Compares Classifier-only Top-1 accuracy vs. Classifier + HMM Viterbi route decoding:
```bash
python -c "
import joblib
from src.data.loader import load_trip
from src.reconstruction.viterbi import compare_classifier_vs_hmm
model = joblib.load('models/tuned_model.joblib')
trip = load_trip('00000000', partition='student_test')
res = compare_classifier_vs_hmm(trip, model)
print('Trip 00000000 Decoded Accuracy:', res['hmm_decoded_accuracy'])
print('Trip 00000000 Route Continuity:', res['hmm_continuity'])
"
```

---

## 💻 Two-Laptop Distributed Deployment

The application strictly implements the **Two-Laptop Architecture** required by the hackathon evaluation guidelines:

### Laptop 1: Inference Server (API & Model Host)
1. Determine Laptop 1's local IP address (`ipconfig` on Windows or `ifconfig` on Linux, e.g. `192.168.1.50`).
2. Launch the FastAPI server bound to `0.0.0.0`:
```bash
python -m uvicorn src.api.main:app --host 0.0.0.0 --port 8000
```
3. API documentation is accessible at `http://localhost:8000/docs`.

### Laptop 2: Evaluator Dashboard (Streamlit UI)
1. Ensure Laptop 2 is connected to the same local network or Wi-Fi.
2. Launch the Streamlit frontend:
```bash
streamlit run frontend/app.py --server.port 8501
```
3. In the sidebar, set the **FastAPI Backend URL** to Laptop 1's IP address:
   `http://192.168.1.50:8000`
4. Select any of the 10 evaluation trips from the dropdown and click **"🚀 Run Map Reconstruction"**.
5. The UI displays real-time observation accuracy, route continuity, and interactive Folium maps comparing raw GPS with the reconstructed route.

---

## 📊 Measured Experimental Highlights

- **Dataset Scale**: Evaluated across 80 training trips (208,417 GPS observations) and 10 testing trips (19,160 GPS observations).
- **Candidate Generation**: Spatial indexing achieves **100% Candidate Recall (0.00% Miss Rate)**.
- **Model Comparison**:
  - **Random Forest**: CV Macro F1: **0.8469**, Student-Test Macro F1: **0.8647**
  - **HistGradientBoosting**: CV Macro F1: **0.8388**, Student-Test Macro F1: **0.8476**
  - **KNN (Distance-weighted)**: CV Macro F1: **0.7952**, Student-Test Macro F1: **0.9004**
  - **MLP Neural Network**: CV Macro F1: **0.8368**, Student-Test Macro F1: **0.9310**
  - **Logistic Regression**: CV Macro F1: **0.7107**, Student-Test Macro F1: **0.7274**
- **Bayesian Tuning (Optuna)**: Optimal Trial #6 boosted Random Forest Macro F1 from **0.8647 to 0.8872**.
- **HMM Route Reconstruction**:
  - Trip `00000000`: Pointwise accuracy leaped from **0.04% to 91.77%**; route continuity increased to **98.44%**.
  - Trip `00000007`: Pointwise accuracy leaped from **0.07% to 97.78%**; route continuity reached **99.56%**.
  - Trip `00000009`: Pointwise accuracy leaped from **0.10% to 85.03%**; route continuity reached **94.47%**.

---

## 📄 Documentation Links
- **[Final Technical Report](file:///c:/Users/Admin/Downloads/PathSnap_Phase1_Team_Scaffold/docs/FINAL_TECHNICAL_REPORT.md)** — Comprehensive hackathon report with methodology, formulas, tables, and graphs.
- **[Integration Contract](file:///c:/Users/Admin/Downloads/PathSnap_Phase1_Team_Scaffold/docs/INTEGRATION_CONTRACT.md)** — Module interface standards.
- **[Interactive Map Visualization](file:///c:/Users/Admin/Downloads/PathSnap_Phase1_Team_Scaffold/results/maps/map_trip_00000000_comparison.html)** — Multi-layer Folium map view.
