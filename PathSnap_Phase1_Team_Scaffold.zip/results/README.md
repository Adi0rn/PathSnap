# Results
Store actual experiment outputs here. Never create or report fabricated metrics.
Recommended subfolders: `eda/`, `model_comparison/`, `optimization/`, `maps/`, `logs/`.
