# Notebooks
Use notebooks for exploratory analysis, but keep reusable source logic in `src/`. Include notebook outputs only when they are genuine and reproducible.
