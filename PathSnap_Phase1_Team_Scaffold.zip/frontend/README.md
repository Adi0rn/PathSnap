# Frontend (Member C)
Build the evaluator UI here. Keep it able to select a permitted student-test trip, call the API and display route/map/metrics. Do not embed hardcoded prediction results in the final app. Mock responses may only be used during development and must be clearly labelled and removed for final demo.
