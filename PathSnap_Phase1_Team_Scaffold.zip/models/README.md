# Model artifacts
Store selected reproducible model artifacts and accompanying feature/config metadata here. Do not commit oversized or unnecessary intermediate artifacts.
