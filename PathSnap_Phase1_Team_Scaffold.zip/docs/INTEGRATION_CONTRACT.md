# Integration Contract (keep names stable)

## Shared conventions
- Dataset partitions are named `train`, `student_test`, and `evaluator_test` only if present in the supplied data.
- Never read/use evaluator-test ground truth during development. The prediction pipeline must not load evaluator `.route` labels.
- Each trip folder contains same-ID `.track`, `.nodes`, `.arcs`, and optionally `.route` files.
- File formats are described in the supplied Dataset Exploration PDF; verify actual files before relying on assumptions.
- Coordinates must be consistently ordered and distance calculations must use suitable geodesic/projected units.

## Member A: Data & features
Owned: `src/data/`, `src/features/`
Stable functions:
```python
load_trip(trip_id: str, partition: str, data_root: str)
generate_candidates(track, nodes, arcs, config=None)
extract_candidate_features(track, candidates, nodes, arcs)
build_training_dataset(trip_ids, data_root, partition="train")
```
Suggested output: dataframe with `trip_id`, `gps_index`, `candidate_arc_id`, feature columns, and `label` (label only for permitted training data). Keep reference route out of prediction features.

## Member B: Models & training
Owned: `src/models/`, `src/training/`, `src/evaluation/`
Stable functions:
```python
train_models(training_dataframe, config=None)
predict_candidates(feature_dataframe, model=None)
evaluate_model(y_true, y_pred, y_prob=None)
```
Prediction dataframe should preserve `trip_id`, `gps_index`, `candidate_arc_id`, and add `score`/`probability` where supported. Persist model and feature metadata.

## Member C: Reconstruction & application
Owned: `src/reconstruction/`, `src/api/`, `frontend/`
Stable function:
```python
decode_route(track, candidate_predictions, road_graph, config=None)
```
API endpoints initially planned: `GET /health`, `GET /trips`, `POST /predict/{trip_id}`. Return JSON with trip ID, predictions, route arc IDs and metrics only when labels are permitted.

## Integration flow
Trip files -> loader -> candidate generation -> features -> trained candidate scorer -> decoder -> route output/map -> API -> UI.

Do not silently alter signatures. If an interface needs to change, update this document and tell all teammates.
