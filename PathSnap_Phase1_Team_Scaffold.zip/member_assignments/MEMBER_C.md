# Member C — HMM/Viterbi, API & UI
Branch: `member-c/hmm-api-ui`
Own only `src/reconstruction/`, `src/api/`, `frontend/`, `tests/test_api/`.
Tasks: route decoder; route continuity; FastAPI; UI trip selector/map/results; API integration tests. Start with clearly-labelled mock interfaces if needed, but remove mocks for final demo. Do not access evaluator-test labels. Push branch and provide run instructions.
