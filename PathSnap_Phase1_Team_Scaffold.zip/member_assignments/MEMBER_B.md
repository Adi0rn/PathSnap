# Member B — Models & Training
Branch: `member-b/model-training`
Own only `src/models/`, `src/training/`, `src/evaluation/`, `tests/test_models/`, and `results/model_comparison/`.
Tasks: at least five models; trip/group-aware CV using training trips; student-test development comparison as allowed; metrics, plots, timings; selection; Bayesian optimization; save actual model artifacts and trials. Do not use evaluator-test labels. Push branch and provide commands/interfaces.
