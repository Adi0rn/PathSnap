# Member A — Data, Candidates & Features
Branch: `member-a/data-features`
Own only `src/data/`, `src/features/`, `tests/test_data/`, `tests/test_features/`, and your report notes.
Tasks: inspect files; parse `.track/.nodes/.arcs/.route` (training labels only); EDA; candidate generation; feature extraction; create training rows; geospatial plots; tests. Push branch and provide interface/usage notes.
