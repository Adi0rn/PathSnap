# Local dataset placement

Extract the provided dataset while preserving its original directory/file names to:

`data/raw/Student folder/`

Expected layout (verify against actual archive):
```
data/raw/Student folder/
  train/
    <trip_id>/
      <trip_id>.track
      <trip_id>.nodes
      <trip_id>.arcs
      <trip_id>.route
  student_test/
    <trip_id>/
      ...
```

If evaluator-testing files are provided, keep them separate and untouched. Never use evaluator ground-truth `.route` files for training, tuning, UI predictions or development decisions. Dataset files are excluded from Git by `.gitignore`.
