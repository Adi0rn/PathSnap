"""Candidate road-segment generation. Member A."""

def generate_candidates(track, nodes, arcs, config=None):
    """TODO: Generate candidate road arcs per GPS observation; return documented structure."""
    raise NotImplementedError
