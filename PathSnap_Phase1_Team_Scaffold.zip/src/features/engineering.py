"""Candidate feature extraction. Member A."""

def extract_candidate_features(track, candidates, nodes, arcs):
    """TODO: Return candidate rows with trip_id, gps_index, candidate_arc_id and features."""
    raise NotImplementedError
