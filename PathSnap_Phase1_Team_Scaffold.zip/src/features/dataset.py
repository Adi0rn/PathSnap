"""Build labelled candidate dataset using permitted training reference routes. Member A."""

def build_training_dataset(trip_ids, data_root, partition="train"):
    """TODO: Build labels from training reference routes; never use labels as predictors."""
    raise NotImplementedError
