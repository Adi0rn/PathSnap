"""Metrics. Member B."""

def evaluate_model(y_true, y_pred, y_prob=None):
    """TODO: Return actual accuracy, precision/recall/F1, confusion matrix and log loss if valid."""
    raise NotImplementedError
