"""Training and cross-validation orchestration. Member B."""

def train_models(training_dataframe, config=None):
    """TODO: Trip/group-aware CV, fit models, log real metrics/timing, save artifacts."""
    raise NotImplementedError
