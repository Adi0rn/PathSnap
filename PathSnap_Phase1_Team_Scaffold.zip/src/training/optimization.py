"""Bayesian optimization experiment. Member B."""

def optimize_model(training_dataframe, model_name, config=None):
    """TODO: Optimize selected model using permitted training data and retain trial history."""
    raise NotImplementedError
