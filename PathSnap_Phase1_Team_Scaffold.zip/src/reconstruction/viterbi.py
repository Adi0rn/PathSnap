"""HMM/Viterbi route decoding. Member C."""

def decode_route(track, candidate_predictions, road_graph, config=None):
    """TODO: Decode connected road-arc sequence using emission and transition scores."""
    raise NotImplementedError
