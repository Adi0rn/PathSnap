"""Baseline model definitions and candidate scoring. Member B."""

def create_model_suite(random_state=42):
    """TODO: Return at least five distinct model pipelines with documented preprocessing."""
    raise NotImplementedError

def predict_candidates(feature_dataframe, model=None):
    """TODO: Score candidates. Preserve trip_id/gps_index/candidate_arc_id."""
    raise NotImplementedError
