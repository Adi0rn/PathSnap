"""FastAPI app scaffold. Member C."""

from fastapi import FastAPI

app = FastAPI(title="PathSnap API", version="0.1.0")

@app.get("/health")
def health():
    return {"status": "scaffold", "implementation": "pending"}

@app.get("/trips")
def list_trips():
    """TODO: List permitted student-test trip IDs for UI selection."""
    return {"trips": []}

# TODO: Implement POST /predict/{trip_id} and connect actual loader, candidate scorer and decoder.
