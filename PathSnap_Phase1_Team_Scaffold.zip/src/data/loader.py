"""Dataset loading interfaces. Member A: implement and test against actual data."""

from pathlib import Path

def load_trip(trip_id: str, partition: str, data_root: str | Path = "data/raw/Student folder"):
    """Load a trip's track, nodes, arcs and reference route only if permitted.

    TODO: Verify raw formats against the supplied Dataset Exploration guide.
    Prediction/evaluator pipeline must not load evaluator reference labels.
    """
    raise NotImplementedError("Member A: implement raw trip loader")
