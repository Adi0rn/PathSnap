"""Dataset exploratory analysis helpers. Member A."""

def summarize_partition(data_root, partition):
    """TODO: Report trip/file counts, observations, nodes/arcs, missingness and anomalies."""
    raise NotImplementedError
